export const environment = {
    apiBase: 'https://pre.svocloud.com'
}