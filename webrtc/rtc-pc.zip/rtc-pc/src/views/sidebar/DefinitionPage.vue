<template>
  <div class="definitionPage">呼叫速率</div>
</template>

<script>
export default {
  name: "definitionPage"
};
</script>

<style lang="scss" scoped>
</style>