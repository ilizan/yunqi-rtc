<template>
  <div class="videoPage">视频设置</div>
</template>

<script>
export default {
  name: "videoPage"
};
</script>

<style lang="scss" scoped>
</style>