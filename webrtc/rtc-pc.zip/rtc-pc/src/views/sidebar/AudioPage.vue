<template>
  <div class="audioPage">音频设置</div>
</template>

<script>
export default {
  name: "audioPage"
};
</script>

<style lang="scss" scoped>
</style>