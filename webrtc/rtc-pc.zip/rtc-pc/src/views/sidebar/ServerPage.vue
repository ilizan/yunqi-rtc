<template>
  <div class="serverPage">设置服务器</div>
</template>

<script>
export default {
  name: "serverPage"
};
</script>

<style lang="scss" scoped>
</style>