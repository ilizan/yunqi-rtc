<template>
  <div class="meeting">
    入会
  </div>
</template>

<script>

export default {
  name: "meeting",
  data() {
    return {
    };
  },
  components: {
  },
  methods: {

  }
};
</script>
<style>
.ivu-drawer-body {
  padding: 0;
}
</style>